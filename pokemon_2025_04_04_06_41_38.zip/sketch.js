let tileMap;
let cols = 31; // 홀수로 유지
let rows = 21;
let tileSize = 24;

let playerX = 1, playerY = 1;
let inBattle = false;

let grassImg, pathImg, gymImg;  // 체육관 이미지 추가

// 이미지가 없다면 색상으로 그려도 동작
function preload() {
  grassImg = loadImage('grass.png'); // 풀숲 이미지
  pathImg = loadImage('path.png');   // 길 이미지
  gymImg = loadImage('gym.png');     // 체육관 이미지 (오른쪽 아래에 넣을 이미지)
}

function setup() {
  createCanvas(cols * tileSize, rows * tileSize);
  tileMap = generateRandomGrassMap(cols, rows);
  frameRate(10);
}

function draw() {
  if (inBattle) {
    drawBattle();
  } else {
    drawMap();
    drawPlayer();
    checkForBattle();
    checkPlayerPosition(); // 플레이어 위치 체크
  }
}

// === 랜덤한 풀숲/길 맵 생성 ===
function generateRandomGrassMap(cols, rows) {
  let temp = [];

  // 기본 맵 초기화 (전체는 길)
  for (let y = 0; y < rows; y++) {
    temp[y] = [];
    for (let x = 0; x < cols; x++) {
      if (y === 0 || y === rows - 1 || x === 0 || x === cols - 1) {
        temp[y][x] = 3; // 테두리 벽은 3으로 설정 (흰색 벽)
      } else {
        temp[y][x] = 0; // 기본은 길
      }
    }
  }

  // 풀숲 덩어리 배열 (여러 크기로 정의)
  let grassChunks = [
    [[1, 1]], // 2x1 크기
    [[1, 1, 1]], // 3x1 크기
    [[1, 1, 1, 1]], // 4x1 크기
    [[1, 1], [1, 1]], // 2x2 크기
    [[1, 1, 1], [1, 1, 1]], // 3x2 크기
    [[1, 1, 1], [1, 1, 1], [1, 1, 1]], // 3x3 크기
  ];

  // 랜덤한 위치에 풀숲 덩어리 배치
  for (let i = 0; i < cols * rows * 0.1; i++) { // 풀숲이 차지할 비율을 0.1로 설정
    let randChunk = random(grassChunks); // 랜덤으로 덩어리 선택
    let randX = int(random(cols));
    let randY = int(random(rows));

    // 덩어리가 맵 밖으로 나가지 않게 위치 확인
    if (randX + randChunk[0].length <= cols && randY + randChunk.length <= rows) {
      for (let y = 0; y < randChunk.length; y++) {
        for (let x = 0; x < randChunk[y].length; x++) {
          if (temp[randY + y][randX + x] !== 3) { // 벽에겐 풀숲이 들어가지 않게
            temp[randY + y][randX + x] = 1; // 덩어리 배치
          }
        }
      }
    }
  }

  return temp;
}

function drawMap() {
  background(220); // 맵의 기본 배경을 한 번만 그립니다.
  
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      let px = x * tileSize;
      let py = y * tileSize;

      if (tileMap[y][x] === 1) {
        // 풀숲 (타일마다 풀숲 그리기)
        if (grassImg) {
          image(grassImg, px, py, tileSize, tileSize);
        } else {
          fill(100, 200, 100);
          rect(px, py, tileSize, tileSize);
        }
      } else if (tileMap[y][x] === 2) {
        // 체육관이 있는 곳에는 체육관 이미지 출력
        image(gymImg, px, py, tileSize * 5, tileSize * 5);  // 체육관 이미지 크기
      } else if (tileMap[y][x] === 3) {
        // 테두리 벽 (흰색 벽)
        fill(255);
        rect(px, py, tileSize, tileSize);
      } else {
        // 길 (타일마다 길 그리기)
        if (pathImg) {
          image(pathImg, px, py, tileSize, tileSize);
        } else {
          fill(200);
          rect(px, py, tileSize, tileSize);
        }
      }
    }
  }
}

function drawPlayer() {
  fill(255, 0, 0);
  rect(playerX * tileSize, playerY * tileSize, tileSize, tileSize);
}

function keyPressed() {
  if (inBattle) return;

  let newX = playerX;
  let newY = playerY;

  if (keyCode === LEFT_ARROW) newX--;
  else if (keyCode === RIGHT_ARROW) newX++;
  else if (keyCode === UP_ARROW) newY--;
  else if (keyCode === DOWN_ARROW) newY++;

  // 이동 제한 (범위 확인 + 벽 뚫기 방지 선택 가능)
  if (newX >= 0 && newX < cols && newY >= 0 && newY < rows) {
    playerX = newX;
    playerY = newY;
  }

  // 스페이스바로 맵 리셋
  if (key === ' ') {
    tileMap = generateRandomGrassMap(cols, rows); // 새로운 맵 생성
    playerX = 1;
    playerY = 1;
    inBattle = false;
  }
}

// 플레이어 위치 체크 (0, x 나 x, 0에 도달하면 반대쪽으로 이동)
function checkPlayerPosition() {
  // 왼쪽 벽에 도달하면 오른쪽 끝으로 이동
  if (playerX == 0) {
    playerX = cols - 2;
    tileMap = generateRandomGrassMap(cols, rows);
  } 
  // 오른쪽 벽에 도달하면 왼쪽 끝으로 이동
  else if (playerX == cols - 1) {
    playerX = 1;
    tileMap = generateRandomGrassMap(cols, rows);
  }

  // 위쪽 벽에 도달하면 아래쪽 끝으로 이동
  if (playerY == 0) {
    playerY = rows - 2;
    tileMap = generateRandomGrassMap(cols, rows);
  } 
  // 아래쪽 벽에 도달하면 위쪽 끝으로 이동
  else if (playerY == rows - 1) {
    playerY = 1;
    tileMap = generateRandomGrassMap(cols, rows);
  }

  // 맵 갱신
  
}

function checkForBattle() {
  if (tileMap[playerY][playerX] === 1) {
    if (random(1) < 0.05) {
      inBattle = true;
    }
  }
}

function drawBattle() {
  background(0);
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text("야생의 포켓몬 등장!", width / 2, height / 2);
}
